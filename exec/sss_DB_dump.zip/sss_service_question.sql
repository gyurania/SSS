-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a606.p.ssafy.io    Database: sss_service
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `question_no` int NOT NULL AUTO_INCREMENT,
  `question_context` varchar(255) NOT NULL,
  PRIMARY KEY (`question_no`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,'아이가 이름을 불렀을 때 돌아보나요?'),(2,'아이와 눈을 맞추는 게 어려운가요?'),(3,'아이가 혼자 놀 때, 물건을 일렬로 세우거나 정렬하는 행동을 자주 하나요?'),(4,'아이가 원하는 물건을 정확하게 가리키나요?'),(5,'아이가 선풍기나 세탁기와 같이 회전하는 물체에 오래 관심을 두나요?'),(6,'아이가 얼마나 많은 단어를 말할 수 있나요?'),(7,'아이가 인형 놀이, 장난감 전화기로 전화하기 와 같은 역할 놀이를 할 수 있나요?'),(8,'아이가 코를 킁킁 거리거나 물건을 핥는 행동을 자주 하나요?'),(9,'생활 방식이 바뀌거나 환경이 달라졌을 때 아이가 쉽게 적응하나요?'),(10,'아이가 수도꼭지를 돌리거나 불을 껐다 켜는 등 반복적인 행동을 자주 하나요?'),(11,'아이가 또래 아이들과 비교했을 때 언제 말을 시작했나요?'),(12,'아이가 부모님의 말이나 소리를 그대로 따라하나요?'),(13,'아이가 소음에 지나치게 민감한가요?'),(14,'다른 사람이 아이의 말을 쉽게 이해하나요?'),(15,'아이가 친구들과 어울리는데 어려움이 있나요?'),(16,'아이가 재밌는 광경을 봤을 때 부모님께 말해주나요?'),(17,'아이가 부모님이 보는 것을 따라 보나요?'),(18,'아이의 목소리가 지나치게 크거나 작은가요?'),(19,'부모님이나 친구가 화났을 때 아이가 위로하려고 하나요?'),(20,'아이가 한 가지 주제에 얼마나 오랫동안 관심을 가지나요?'),(21,'아이가 손을 흔들며 인사하는 등의 손 운동을 잘 하나요?'),(22,'아이의 걸음걸이가 자연스러운가요?'),(23,'아이가 무호흡 혹은 과호흡과 같은 호흡 불량 증상을 보이나요?');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:31:46
