-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a606.p.ssafy.io    Database: sss_service
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_expertise_therapist`
--

DROP TABLE IF EXISTS `b_expertise_therapist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_expertise_therapist` (
  `b_expertise_therapist_no` int NOT NULL AUTO_INCREMENT,
  `expertise_no` int NOT NULL,
  `thera_id` varchar(255) NOT NULL,
  PRIMARY KEY (`b_expertise_therapist_no`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_expertise_therapist`
--

LOCK TABLES `b_expertise_therapist` WRITE;
/*!40000 ALTER TABLE `b_expertise_therapist` DISABLE KEYS */;
INSERT INTO `b_expertise_therapist` VALUES (1,1,'tLQDOys220805'),(2,2,'tLQDOys220805'),(3,3,'tLQDOys220805'),(4,5,'tLQDOys220805'),(5,1,'to46qFg220805'),(6,2,'to46qFg220805'),(7,5,'to46qFg220805'),(8,2,'toqyD0t220805'),(9,3,'tQ33VQz220805'),(10,4,'tQ33VQz220805'),(11,5,'tQ33VQz220805'),(12,1,'tsCvksB220804'),(13,2,'tlAN5Qf220805'),(14,3,'tlAN5Qf220805'),(15,4,'tlAN5Qf220805'),(16,1,'tvSV0xI220804'),(17,5,'tvSV0xI220804'),(18,2,'tvSV0xI2a0804'),(19,4,'tvSV0xI2a0804'),(20,5,'tvSV0xI2a0804'),(21,5,'tvSV0xI2b0804'),(22,1,'tvSV0xI2c0804'),(23,2,'tvSV0xI2c0804'),(24,3,'tvSV0xI2c0804'),(25,4,'tvSV0xI2c0804'),(26,1,'tvSV0xI2d0804'),(27,2,'tvSV0xI2d0804'),(28,1,'tvSV0xI2e0804'),(29,3,'tvSV0xI2e0804'),(30,2,'tvSV0xI2f0804'),(31,5,'tvSV0xI2f0804'),(32,3,'tvSV0xI2g0804'),(33,5,'tvSV0xI2g0804'),(34,3,'tvSV0xI2h0804'),(35,4,'tvSV0xI2h0804'),(36,5,'tvSV0xI2h0804'),(37,3,'tvSV0xI2i0804'),(38,5,'tvSV0xI2i0804'),(39,1,'tvSV0xI2j0804'),(40,3,'tvSV0xI2j0804'),(41,4,'tvSV0xI2j0804'),(42,2,'tvSV0xI2k0804'),(43,5,'tvSV0xI2k0804'),(44,1,'tvSV0xI2l0804'),(45,3,'tvSV0xI2l0804'),(46,4,'tvSV0xI2l0804'),(47,2,'tvSV0xI2n0804'),(48,3,'tvSV0xI2n0804'),(49,1,'tWYjC7k2m0804'),(50,2,'tWYjC7k2m0804'),(51,5,'tWYjC7k2m0804');
/*!40000 ALTER TABLE `b_expertise_therapist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:31:48
