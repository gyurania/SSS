-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a606.p.ssafy.io    Database: sss_auth
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` char(13) NOT NULL,
  `id` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `withdraw_flag` int DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_8qtpnv06elxuryeuv1ac4ximm` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('p0SAddT220804','parent001','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('p3IsNnN220804','parent002','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('p9wj92M220803','parent003','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('pcdHKGY220804','parent004','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('pDj2dJd220805','parent005','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tlAN5Qf220805','therapist006','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tLQDOys220805','therapist001','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('to46qFg220805','therapist002','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('toqyD0t220805','therapist003','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tQ33VQz220805','therapist004','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tsCvksB220804','therapist005','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI220804','therapist007','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2a0804','therapist008','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2b0804','therapist009','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2c0804','therapist010','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2d0804','therapist011','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2e0804','therapist012','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2f0804','therapist013','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2g0804','therapist014','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2h0804','therapist015','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2i0804','therapist016','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2j0804','therapist017','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2k0804','therapist018','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2l0804','therapist019','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tvSV0xI2n0804','therapist020','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0),('tWYjC7k2m0804','therapist021','$2a$10$8XFG9jG4dtHwseg/liZFreGGm1GCL4E1paqm3r1UaAxZ1jcHdrf/u',NULL,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:31:48
