-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a606.p.ssafy.io    Database: sss_auth
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `child`
--

DROP TABLE IF EXISTS `child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `child` (
  `child_no` int NOT NULL AUTO_INCREMENT,
  `birth` date NOT NULL,
  `child_id` char(13) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  `survey_flag` int DEFAULT '0',
  `parent_id` char(13) NOT NULL,
  PRIMARY KEY (`child_no`),
  UNIQUE KEY `UK_ngu6gf0xmcr2n7lxu3ij2vxla` (`child_id`),
  KEY `FK7dag1cncltpyhoc2mbwka356h` (`parent_id`),
  CONSTRAINT `FK7dag1cncltpyhoc2mbwka356h` FOREIGN KEY (`parent_id`) REFERENCES `parent` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `child`
--

LOCK TABLES `child` WRITE;
/*!40000 ALTER TABLE `child` DISABLE KEYS */;
INSERT INTO `child` VALUES (1,'2015-07-23','cMJwqp1220804','남자','정진욱','Delivery boy-3.png',1,'p0SAddT220804'),(2,'2018-05-10','cMJwqp2220804','남자','정세혁','Delivery boy-4.png',1,'p0SAddT220804'),(3,'2017-01-22','cMJwqp3220804','여자','이영아','Delivery boy-5.png',0,'p3IsNnN220804'),(4,'2013-12-24','cMJwqp4220804','남자','이한결','E-commerce.png',1,'p3IsNnN220804'),(5,'2012-08-03','cMJwqp5220804','여자','양빛가람','E-commerce-1.png',0,'p9wj92M220803'),(6,'2013-10-23','cMJwqp6220804','여자','양가은','E-commerce-2.png',1,'p9wj92M220803'),(7,'2018-08-28','cMJwqp7220804','남자','양민수','Funny Bunny.png',1,'p9wj92M220803'),(8,'2013-02-22','cMJwqp8220804','남자','김우람','Funny Bunny-1.png',1,'pcdHKGY220804'),(9,'2015-11-10','cMJwqp9220804','남자','김단비','Funny Bunny-2.png',0,'pcdHKGY220804'),(10,'2016-12-01','cMJwq10220804','남자','김라온','Funny Bunny-3.png',0,'pcdHKGY220804'),(11,'2018-04-01','cMJwq11220804','여자','남슬아','Funny Bunny-3.png',1,'pDj2dJd220805');
/*!40000 ALTER TABLE `child` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:31:48
