-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a606.p.ssafy.io    Database: sss_service
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer` (
  `answer_no` int NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `answer` text NOT NULL,
  `child_id` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  `score1` int NOT NULL,
  `score2` int NOT NULL,
  `score3` int NOT NULL,
  PRIMARY KEY (`answer_no`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (1,'2022-08-18 15:08:01','전혀 보지 않음,불가능함,항상 함,전혀 가리키지 않음,몇 시간 동안 관심을 둠,아직 말하지 못함,전혀 하지 않음,매우 자주 함,전혀 적응하지 못함,매일 많이 함,매우 늦게 시작함,매일 자주 따라함,아주 민감함,거의 이해하지 못함,거의 어울리지 못함,전혀 공유하지 않음,전혀 따라보지 않음,지나치게 크거나 작음,전혀 관심없음,몇 일,잘 하지 못함,팔자걸음이 심함,일주일에 한 번 이하로 일어남,','cMJwqp1220804','2022-08-18 15:08:01',83,30,6),(2,'2022-08-18 12:10:13','전혀 보지 않음,불가능함,자주 함,일주일에 몇 번 정도 가리킴,1-2분 정도 관심을 둠,51-100개 단어를 사용함,일주일에 한 번 정도 함,일주일에 한 번 이하로 함,꽤 어렵게 적응함,일주일에 몇 번 함,꽤 늦게 시작함,일주일에 몇 번 따라함,가끔 민감함,가끔 이해함,어울리기는 하나 대화하기 어려움,하루에 한 두 번 공유함,일주일에 몇 번 따라 봄,가끔 있음,가끔 위로하려 함,몇 시간,잘 하지 못함,팔자걸음이 심함,일주일에 몇 번 정도 일어남,','cMJwqp2220804','2022-08-16 12:10:13',49,16,7),(3,'2022-08-18 15:10:10','자주 돌아봄,꽤 어려움,거의 하지 않음,하루에 몇 번 정도 가리킴,1-2분 정도 관심을 둠,10-50개 단어를 사용함,일주일에 한 번도 하지 않음,일주일에 몇 번 정도 함,아주 어렵게 적응함,하루에 몇 번 함,매우 늦게 시작함,일주일에 몇 번 따라함,꽤 민감함,거의 이해하지 못함,거의 어울리지 못함,일주일에 한 두 번 공유함,일주일에 몇 번 따라 봄,종종 있음,대부분 관심없음,몇 시간,잘 하지 못함,팔자걸음이 심함,일주일에 몇 번 정도 일어남,','cMJwqp4220804','2022-08-18 15:10:10',53,22,7),(4,'2022-08-18 15:10:01','가끔 돌아봄,많이 어려움,자주 함,일주일에 몇 번 정도 가리킴,10분 정도 관심을 둠,아직 말하지 못함,일주일에 한 번도 하지 않음,일주일에 몇 번 정도 함,꽤 어렵게 적응함,일주일에 몇 번 함,꽤 늦게 시작함,일주일에 몇 번 따라함,가끔 민감함,가끔 이해함,친구들과 전혀 어울리지 못함,하루에 한 두 번 공유함,전혀 따라보지 않음,거의 없음,가끔 위로하려 함,몇 시간,잘 하지 못함,다리가 굽혀지지 않고 뻣뻣함,하루에 몇 번 정도 일어남,','cMJwqp6220804','2022-08-18 15:10:01',58,19,10),(5,'2022-08-18 15:08:03','자주 돌아봄,꽤 어려움,거의 하지 않음,하루에 몇 번 정도 가리킴,1-2분 정도 관심을 둠,10-50개 단어를 사용함,일주일에 한 번도 하지 않음,일주일에 몇 번 정도 함,아주 어렵게 적응함,하루에 몇 번 함,매우 늦게 시작함,일주일에 몇 번 따라함,꽤 민감함,거의 이해하지 못함,거의 어울리지 못함,일주일에 한 두 번 공유함,일주일에 몇 번 따라 봄,종종 있음,대부분 관심없음,몇 시간,잘 하지 못함,팔자걸음이 심함,일주일에 몇 번 정도 일어남,','cMJwqp7220804','2022-08-18 15:08:03',53,22,7),(6,'2022-08-18 13:08:01','전혀 보지 않음,불가능함,항상 함,전혀 가리키지 않음,몇 시간 동안 관심을 둠,아직 말하지 못함,전혀 하지 않음,매우 자주 함,전혀 적응하지 못함,매일 많이 함,매우 늦게 시작함,매일 자주 따라함,아주 민감함,거의 이해하지 못함,거의 어울리지 못함,전혀 공유하지 않음,전혀 따라보지 않음,지나치게 크거나 작음,전혀 관심없음,몇 일,잘 하지 못함,팔자걸음이 심함,일주일에 한 번 이하로 일어남,','cMJwqp8220804','2022-08-18 13:08:01',83,30,6),(7,'2022-08-18 15:13:10','자주 돌아봄,꽤 어려움,거의 하지 않음,하루에 몇 번 정도 가리킴,1-2분 정도 관심을 둠,10-50개 단어를 사용함,일주일에 한 번도 하지 않음,일주일에 몇 번 정도 함,아주 어렵게 적응함,하루에 몇 번 함,매우 늦게 시작함,일주일에 몇 번 따라함,꽤 민감함,거의 이해하지 못함,거의 어울리지 못함,일주일에 한 두 번 공유함,일주일에 몇 번 따라 봄,종종 있음,대부분 관심없음,몇 시간,잘 하지 못함,팔자걸음이 심함,일주일에 몇 번 정도 일어남,','cMJwq11220804','2022-08-18 15:13:10',53,22,7);
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:31:45
